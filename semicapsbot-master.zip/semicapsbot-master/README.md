## Description coming soon
requirements.txt coming soon too
cicd and docker just for skill improvements